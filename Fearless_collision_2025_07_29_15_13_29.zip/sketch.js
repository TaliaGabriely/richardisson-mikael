function setup() {
  createCanvas(4000, 4000);
}

function draw() {
  background(102,205,170);
}